class Redencion < ApplicationRecord
  belongs_to :detalleparametros
end
