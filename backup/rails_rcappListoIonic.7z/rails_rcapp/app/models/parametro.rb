class Parametro < ApplicationRecord
end
