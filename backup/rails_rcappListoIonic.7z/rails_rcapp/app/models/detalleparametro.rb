class Detalleparametro < ApplicationRecord
  belongs_to :parametros
end
