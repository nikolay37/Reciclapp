class Metum < ApplicationRecord
  belongs_to :retos
  belongs_to :detalleparametros
end
