class Reto < ApplicationRecord
  belongs_to :users
end
