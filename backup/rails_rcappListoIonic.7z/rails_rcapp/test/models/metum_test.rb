require 'test_helper'

class MetumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
