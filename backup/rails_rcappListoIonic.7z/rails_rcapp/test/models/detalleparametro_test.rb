require 'test_helper'

class DetalleparametroTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
