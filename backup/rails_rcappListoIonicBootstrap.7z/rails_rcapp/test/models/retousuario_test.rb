require 'test_helper'

class RetousuarioTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
