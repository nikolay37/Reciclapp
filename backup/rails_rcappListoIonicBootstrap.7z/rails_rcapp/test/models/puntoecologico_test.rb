require 'test_helper'

class PuntoecologicoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
