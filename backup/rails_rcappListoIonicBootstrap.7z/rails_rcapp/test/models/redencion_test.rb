require 'test_helper'

class RedencionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
