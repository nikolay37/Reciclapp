class Ventum < ApplicationRecord
  belongs_to :detalleparametros
  belongs_to :redencions
end
