class Recoleccion < ApplicationRecord
  belongs_to :retousuarios
  belongs_to :detalleparametros
end
